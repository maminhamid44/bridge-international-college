
function toggleMenu(){document.getElementById('links').classList.toggle('active')}
document.querySelectorAll('.links a').forEach(a=>a.addEventListener('click',()=>document.getElementById('links').classList.remove('active')));
function register(e){e.preventDefault();let u={name:rname.value,email:remail.value,program:rprogram.value};localStorage.setItem('student',JSON.stringify(u));alert('Registration saved successfully!');e.target.reset()}
function login(e){e.preventDefault();let u=JSON.parse(localStorage.getItem('student')||'null');let email=lemail.value;if(u&&email===u.email){localStorage.setItem('loggedIn','yes');alert('Login successful!');location.href='student-dashboard.html'}else alert('Demo login: register first using the same email.')}
function logout(){localStorage.removeItem('loggedIn');location.href='index.html'}
function send(e){e.preventDefault();alert('Thank you! Your message has been submitted.');e.target.reset()}
function loadStudent(){let u=JSON.parse(localStorage.getItem('student')||'null');if(u){document.querySelectorAll('[data-student-name]').forEach(x=>x.textContent=u.name);document.querySelectorAll('[data-student-email]').forEach(x=>x.textContent=u.email);document.querySelectorAll('[data-student-program]').forEach(x=>x.textContent=u.program)}}
