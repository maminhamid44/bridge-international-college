BRIDGE INTERNATIONAL COLLEGE WEBSITE

Files:
- index.html: Home
- about.html: About
- academics.html: Academic programs
- admissions.html: Admissions
- student-life.html: Student life
- research.html: Research
- alumni.html: Alumni
- resources.html: Library/resources
- news.html: News & events
- contact.html: Contact form
- register.html: Student registration
- login.html: Student login
- student-dashboard.html: Demo student portal
- admin.html: Demo admin dashboard
- style.css: Main responsive styling
- script.js: Navigation, forms and localStorage demo

HOW TO USE:
1. Extract the ZIP.
2. Open index.html in Chrome/Edge/Firefox.
3. Use Register to create a demo student.
4. Login using the same email.
5. The student dashboard stores demo data in browser localStorage.

NOTE:
This is a front-end/demo system. Login, grades, payments and admin data are not connected to a real database.
